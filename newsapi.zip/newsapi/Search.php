<?php
use jcobhams\NewsApi\NewsApi;
use jcobhams\NewsApi\NewsApiException;

defined('ABSPATH' ) || exit();

class Search {

	private NewsApi $news;

	public function __construct() {
		add_action( 'cmb2_admin_init', [$this, 'news_api_options']);
		$api = $this->field('news_api_key');
		if(!$api){
			return false;
		}
		$this->news =  new NewsApi($api);
		add_shortcode('search-news-list', [$this, 'do_query_keyword_shortcode']);
		add_action('wp_enqueue_scripts', [$this, 'script_css_register']);
	}

	public function news_api_options(){
		$cmb = new_cmb2_box([
			'id'           => 'news_api_options_page',
			'title'        => 'News API 设置',
			'object_types' => array('options-page'),
			'option_key'      => 'news_api_options',
			'icon_url'        => 'dashicons-palmtree',
		]);
		$cmb->add_field([
			'name'    => 'API KEY',
			'id'      => 'news_api_key',
			'type'    => 'text',
			'default' => 'a19e03e3fe484881805f31ce994dbcd6'
		]);

		$cmb->add_field([
			'name'    => '查询字符串',
			'id'      => 'query_string',
			'type'    => 'text',
			'default' => 'news2'
		]);

		$cmb->add_field([
			'name'    => '头条查询关键词',
			'id'      => 'headline_keyword',
			'type'    => 'text',
			'default' => 'top'
		]);
		$cmb->add_field([
			'name'    => '头条显示总数',
			'id'      => 'headline_count',
			'type'    => 'text',
			'default' => '6',
			'after_row' => '<div style="margin: 20px auto; padding: 20px; background: #fff;">新建页面加入 <code>[search-news-list] </code> 代码</div>'
		]);
	}

	public function script_css_register(){
		$css = NEWS_LINK . '/news.css';
		wp_enqueue_style('news', $css);
	}

	private function field($key) {
		$options = get_option('news_api_options');
		if(!$options){
			return '';
		}
		return $options[ $key ] ?? '';
	}

	public function do_query_keyword_shortcode(){
		try {
			$q =  $this->field('query_string');
			$keyword = isset($_GET[$q]) ? sanitize_text_field($_GET[$q]) : '';
			if($keyword){
				$list = $this->news->getEverything($keyword);
				$__cc = $list->totalResults;
			}else{
				$top_keyword = $this->field('headline_keyword');
				$list = $this->news->getTopHeadLines($top_keyword);
				$__cc = $this->field('headline_count');
			}
		} catch ( NewsApiException $e ) {
			$html  = '<div id="error">';
			$html .= $e->getMessage();
			$html .= '</div>';
			return $html;
		}
		if($list->totalResults > 1){

			$current_uri = $_SERVER['REQUEST_URI'];

			$html = '<div id="search2">';
			$html .= '<form action="'. $current_uri .'" method="get">';
			$html .= '<input type="text" name="' . $q . '" value="'. $keyword .'" required/>';
			$html .= '<input type="submit" value="Submit" />';
			$html .= '</form>';
			$html .= '</div>';


			$html .= '<div id="news2">';
			$i=0;
			foreach ($list->articles as $key => $item){
				if(!$item->title || !$item->url || !$item->urlToImage || !$item->description || !$item->author){
					continue;
				}
				$i += 1;
				$html .= '<div class="item top">';
				$html .= '<a href="' . $item->url . '">';
				$html .= '<img src="' . $item->urlToImage . '" alt="' . $item->title . '">';
				$html .= '</a>';
				$html .= '<div class="content">';
				$html .= '<h3> <a href="">' .$item->title . '</a></h3>';
				$html .= '<div class="description">' . $item->description . '</div>';
				$html .= '<div class="author"><span>' . $item->author . '</span></div>';
				$html .= '<div class="view"><a href="' . $item->url . '">learn more</a></div>';
				$html .= '</div>';
				$html .= '</div>';
				if($i == $__cc){
					break;
				}
			}
			if ($i === 0){
				$html  = '<div class="empty">';
				$html .= 'No Results';
				$html .= '</div>';
			}
			$html .= '</div>';
			return $html;
		}
	}



}