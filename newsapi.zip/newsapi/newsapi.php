<?php
/*
Plugin Name: NEWS API
Description: News API.
Version: 1.0
Requires PHP: 7.4
*/

defined('ABSPATH' ) || exit();


define('NEWS_ROOT', plugin_dir_path(__FILE__));
define('NEWS_LINK', plugin_dir_url(__FILE__));


require_once (NEWS_ROOT . 'vendor/autoload.php');
require_once (NEWS_ROOT . 'cmb2/init.php');
require_once (NEWS_ROOT . 'Search.php');

//echo NEWS_ROOT;
add_action('after_setup_theme', function (){
	new Search();
});
